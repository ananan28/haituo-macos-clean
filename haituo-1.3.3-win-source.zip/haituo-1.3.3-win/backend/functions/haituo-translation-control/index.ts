import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const INSTALL_KEY_HASH = "9383eec54b05f6a8d533df7aea27a486222007d89aa1cd0ca7f0d174b75726a7";
const ADMIN_KEY_HASH = "08d94f4275e718ddd09d7ff03bc90891ef09d74524c7c2a8b92e16de0a9805e9";
const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type,x-haituo-install-key,x-haituo-device-id,x-haituo-device-token,x-haituo-admin-key",
};
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const now = () => new Date().toISOString();
const validPool = (v: unknown) => ["translation_pool", "site_pool", "tn_groups"].includes(String(v)) ? String(v) : "translation_pool";

function reply(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "content-type": "application/json; charset=utf-8" } });
}
async function hash(value: string) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map(v => v.toString(16).padStart(2, "0")).join("");
}
function token(size = 32) {
  const bytes = crypto.getRandomValues(new Uint8Array(size));
  return [...bytes].map(v => v.toString(16).padStart(2, "0")).join("");
}
const requestIp = (req: Request) => (req.headers.get("cf-connecting-ip") || req.headers.get("x-forwarded-for")?.split(",")[0] || "").trim();
const adminAllowed = async (req: Request) => await hash(req.headers.get("x-haituo-admin-key") || "") === ADMIN_KEY_HASH;
const HEALTH_KEY_HASH = "2e5b0dcd7dd5acc3f0cd98cf93bb5f6f93c355aa935475feae5fe12b2e1dad49";
const healthAllowed = async (req: Request) => await hash(req.headers.get("x-haituo-health-key") || "") === HEALTH_KEY_HASH;

async function writeAll(writer: WritableStreamDefaultWriter<Uint8Array>, bytes: Uint8Array) {
  await writer.write(bytes);
}
async function readExact(reader: ReadableStreamDefaultReader<Uint8Array>, size: number) {
  const out = new Uint8Array(size); let offset = 0;
  while (offset < size) {
    const { value, done } = await reader.read();
    if (done || !value) throw new Error("代理连接提前断开");
    const take = Math.min(value.length, size - offset);
    out.set(value.subarray(0, take), offset);
    offset += take;
  }
  return out;
}
async function probeProxy(p: any) {
  const started = Date.now(); let conn: any = null; let timer: number | undefined;
  try {
    const connect = p.protocol === "https" ? Deno.connectTls({ hostname: p.host, port: Number(p.port) }) : Deno.connect({ hostname: p.host, port: Number(p.port) });
    conn = await Promise.race([connect, new Promise((_, reject) => setTimeout(() => reject(new Error("连接超时")), 8000))]);
    timer = setTimeout(() => { try { conn?.close(); } catch {} }, 8000);
    const writer = conn.writable.getWriter(), reader = conn.readable.getReader(), enc = new TextEncoder();
    if (p.protocol === "socks5") {
      await writeAll(writer, new Uint8Array([5, 2, 0, 2]));
      const hello = await readExact(reader, 2);
      if (hello[0] !== 5 || hello[1] === 255) throw new Error("SOCKS5认证方式不支持");
      if (hello[1] === 2) {
        const u = enc.encode(p.username || ""), pw = enc.encode(p.password || "");
        await writeAll(writer, new Uint8Array([1, u.length, ...u, pw.length, ...pw]));
        const auth = await readExact(reader, 2);
        if (auth[1] !== 0) throw new Error("SOCKS5用户名或密码错误");
      }
      const host = enc.encode("translate.googleapis.com");
      await writeAll(writer, new Uint8Array([5, 1, 0, 3, host.length, ...host, 1, 187]));
      const res = await readExact(reader, 4);
      if (res[1] !== 0) throw new Error("SOCKS5无法连接Google翻译");
    } else if (p.protocol === "socks4") {
      const user = enc.encode(p.username || ""), host = enc.encode("translate.googleapis.com");
      await writeAll(writer, new Uint8Array([4, 1, 1, 187, 0, 0, 0, 1, ...user, 0, ...host, 0]));
      const res = await readExact(reader, 8);
      if (res[1] !== 90) throw new Error("SOCKS4连接或认证失败");
    } else {
      const auth = p.username || p.password ? "Proxy-Authorization: Basic " + btoa(String(p.username || "") + ":" + String(p.password || "")) + "\r\n" : "";
      await writeAll(writer, enc.encode("CONNECT translate.googleapis.com:443 HTTP/1.1\r\nHost: translate.googleapis.com:443\r\n" + auth + "Connection: close\r\n\r\n"));
      const { value } = await reader.read();
      const head = new TextDecoder().decode(value || new Uint8Array());
      if (!/^HTTP\/1\.[01] 200\b/.test(head)) throw new Error(/ 407\b/.test(head) ? "HTTP代理用户名或密码错误" : "HTTP代理无法连接Google翻译");
    }
    return { ok: true, latencyMs: Date.now() - started, error: null };
  } catch (e) {
    return { ok: false, latencyMs: null, error: String((e as Error)?.message || e).slice(0, 500) };
  } finally {
    if (timer !== undefined) clearTimeout(timer);
    try { conn?.close(); } catch {}
  }
}
async function checkAndSaveProxy(p: any) {
  const result = await probeProxy(p);
  await db.from("translation_proxy_pool").update({
    health_status: result.ok ? "healthy" : "cooldown",
    latency_ms: result.latencyMs,
    failure_count: result.ok ? 0 : Number(p.failure_count || 0) + 1,
    cooldown_until: result.ok ? null : new Date(Date.now() + 10 * 60 * 1000).toISOString(),
    last_checked_at: now(),
    last_error: result.error,
    updated_at: now(),
  }).eq("id", p.id);
  return result;
}
async function healthSweep() {
  const stale = new Date(Date.now() - 10 * 60 * 1000).toISOString();
  const { data } = await db.from("translation_proxy_pool").select("*").eq("pool_type", "translation_pool").eq("enabled", true).or(`last_checked_at.is.null,last_checked_at.lt.${stale}`).limit(200);
  const rows = data || [];
  for (let i = 0; i < rows.length; i += 10) await Promise.all(rows.slice(i, i + 10).map(checkAndSaveProxy));
  return rows.length;
}

async function deviceFor(req: Request) {
  const publicId = req.headers.get("x-haituo-device-id") || "", deviceToken = req.headers.get("x-haituo-device-token") || "";
  if (!publicId || !deviceToken) return null;
  const { data } = await db.from("translation_proxy_devices").select("*").eq("device_public_id", publicId).eq("status", "active").maybeSingle();
  if (!data || data.device_token_hash !== await hash(deviceToken)) return null;
  const ip = requestIp(req);
  await db.from("translation_proxy_devices").update({ last_seen_at: now(), ...(ip ? { last_ip: ip } : {}) }).eq("id", data.id);
  return { ...data, ...(ip ? { last_ip: ip } : {}) };
}

async function chooseProxy(poolType: string, excluded: string[] = []) {
  await db.from("translation_proxy_pool").update({ health_status: "unknown", cooldown_until: null }).eq("health_status", "cooldown").lte("cooldown_until", now());
  const [{ data: pool, error }, { data: assigned }] = await Promise.all([
    db.from("translation_proxy_pool").select("*").eq("pool_type", poolType).eq("enabled", true).in("health_status", ["healthy", "unknown"]).order("failure_count").order("latency_ms", { ascending: true, nullsFirst: false }).order("last_used_at", { ascending: true, nullsFirst: true }).limit(500),
    db.from("translation_proxy_assignments").select("proxy_id,device_id").eq("status", "active").eq("pool_type", poolType).not("proxy_id", "is", null),
  ]);
  if (error) throw error;
  const devicesByProxy = new Map<string, Set<string>>();
  for (const row of assigned || []) {
    if (!devicesByProxy.has(row.proxy_id)) devicesByProxy.set(row.proxy_id, new Set());
    devicesByProxy.get(row.proxy_id)!.add(row.device_id);
  }
  const counts = new Map<string, number>();
  for (const [proxyId, deviceIds] of devicesByProxy) counts.set(proxyId, deviceIds.size);
  return (pool || []).filter(p => !excluded.includes(p.id) && (counts.get(p.id) || 0) < Number(p.max_accounts || 5)).sort((a, b) => (counts.get(a.id) || 0) - (counts.get(b.id) || 0) || String(a.last_used_at || "").localeCompare(String(b.last_used_at || "")))[0] || null;
}

async function assign(device: any, poolType: string, accountKey: string, excluded: string[] = [], force = false) {
  const { data: current } = await db.from("translation_proxy_assignments").select("*,proxy:translation_proxy_pool(*)").eq("device_id", device.id).eq("pool_type", poolType).eq("account_key", accountKey).maybeSingle();
  const locked = current?.fixed === true || poolType === "tn_groups";
  if (current?.proxy && current.status === "active" && (locked || (!force && !excluded.includes(current.proxy_id))) && current.proxy.enabled && ["healthy", "unknown"].includes(current.proxy.health_status)) return { proxy: current.proxy, assignment: current };
  if (locked && current?.proxy) return { proxy: current.proxy, assignment: current };
  const next = await chooseProxy(poolType, excluded);
  if (!next) return { proxy: null, assignment: current || null };
  const values = { device_id: device.id, pool_type: poolType, account_key: accountKey, proxy_id: next.id, fixed: poolType === "tn_groups", status: "active", updated_at: now() };
  const { data, error } = await db.from("translation_proxy_assignments").upsert(values, { onConflict: "device_id,pool_type,account_key" }).select("*").single();
  if (error) throw error;
  await db.from("translation_proxy_pool").update({ last_used_at: now(), updated_at: now() }).eq("id", next.id);
  return { proxy: next, assignment: data };
}

function publicProxy(row: any) {
  return row ? { id: row.id, label: row.label, protocol: row.protocol, host: row.host, port: row.port, username: row.username, password: row.password, region: row.region, latencyMs: row.latency_ms, poolType: row.pool_type } : null;
}

async function bindDeviceToProxy(deviceId: string, proxyId: string, fixed: boolean) {
  const [{ data: proxy, error: proxyError }, { data: occupied, error: occupiedError }] = await Promise.all([
    db.from("translation_proxy_pool").select("*").eq("id", proxyId).single(),
    db.from("translation_proxy_assignments").select("device_id").eq("proxy_id", proxyId).eq("status", "active"),
  ]);
  if (proxyError) throw proxyError;
  if (occupiedError) throw occupiedError;
  if (!proxy?.enabled || proxy.health_status !== "healthy") throw new Error("所选 IP 当前不可用");
  const usedBy = new Set((occupied || []).map((row: any) => row.device_id).filter((id: string) => id !== deviceId));
  if (usedBy.size >= Number(proxy.max_accounts || 3)) throw new Error("所选 IP 已达到客户端上限");
  const values = { device_id: deviceId, pool_type: "translation_pool", account_key: "default", proxy_id: proxyId, fixed, status: "active", updated_at: now() };
  const { error } = await db.from("translation_proxy_assignments").upsert(values, { onConflict: "device_id,pool_type,account_key" });
  if (error) throw error;
  return proxy;
}
async function autoAssignDevice(deviceId: string) {
  const next = await chooseProxy("translation_pool");
  if (!next) throw new Error("没有可分配的可用 IP");
  const values = { device_id: deviceId, pool_type: "translation_pool", account_key: "default", proxy_id: next.id, fixed: false, status: "active", updated_at: now() };
  const { error } = await db.from("translation_proxy_assignments").upsert(values, { onConflict: "device_id,pool_type,account_key" });
  if (error) throw error;
  await db.from("translation_proxy_pool").update({ last_used_at: now(), updated_at: now() }).eq("id", next.id);
  return next;
}

Deno.serve(async req => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    const body = req.method === "POST" ? await req.json() : {}, action = String(body.action || "");
    if (action === "enroll") {
      if (await hash(req.headers.get("x-haituo-install-key") || "") !== INSTALL_KEY_HASH) return reply({ ok: false, message: "安装凭证无效" }, 403);
      const publicId = String(body.deviceId || "").trim().slice(0, 128);
      if (!publicId) return reply({ ok: false, message: "设备ID为空" }, 400);
      const { data: existing } = await db.from("translation_proxy_devices").select("id,status").eq("device_public_id", publicId).maybeSingle();
      if (existing?.status === "revoked") return reply({ ok: false, message: "设备已被停用" }, 403);
      const deviceToken = token(), ip = requestIp(req);
      const values = { device_public_id: publicId, device_token_hash: await hash(deviceToken), device_name: String(body.deviceName || "海拓设备").slice(0, 120), status: "active", client_version: String(body.version || "").slice(0, 40), last_seen_at: now(), ...(ip ? { last_ip: ip } : {}), updated_at: now() };
      const result = existing ? await db.from("translation_proxy_devices").update(values).eq("id", existing.id).select("id").single() : await db.from("translation_proxy_devices").insert(values).select("id").single();
      if (result.error) throw result.error;
      return reply({ ok: true, deviceId: publicId, deviceToken });
    }

    if (action === "health_sweep") {
      if (!await healthAllowed(req)) return reply({ ok: false, message: "健康检测凭证无效" }, 403);
      const checked = await healthSweep();
      return reply({ ok: true, checked });
    }
    if (action === "binding_self_test") {
      if (!await healthAllowed(req)) return reply({ ok: false, message: "内部测试凭证无效" }, 403);
      const [{ data: devices }, { data: proxies }] = await Promise.all([
        db.from("translation_proxy_devices").select("id,device_name").eq("status", "active").order("created_at").limit(2),
        db.from("translation_proxy_pool").select("*").eq("pool_type", "translation_pool").eq("enabled", true).eq("health_status", "healthy").order("latency_ms").limit(2),
      ]);
      if (!devices?.length || !proxies?.length) throw new Error("测试缺少在线设备或可用 IP");
      const manual = await bindDeviceToProxy(devices[0].id, proxies[0].id, true);
      const automatic = devices[1] ? await autoAssignDevice(devices[1].id) : null;
      return reply({ ok: true, manual: { deviceId: devices[0].id, proxy: publicProxy(manual) }, automatic: automatic ? { deviceId: devices[1].id, proxy: publicProxy(automatic) } : null });
    }

    if (action.startsWith("admin_")) {
      if (!await adminAllowed(req)) return reply({ ok: false, message: "管理密钥无效" }, 403);
      if (action === "admin_snapshot") {
        const [pool, devices, assignments, egress, settings, logs] = await Promise.all([
          db.from("translation_proxy_pool").select("id,label,protocol,host,port,username,region,pool_type,max_accounts,notes,enabled,health_status,latency_ms,failure_count,cooldown_until,last_checked_at,last_used_at,last_error,created_at").order("created_at"),
          db.from("translation_proxy_devices").select("id,device_public_id,device_name,status,client_version,last_seen_at,last_ip,created_at").order("created_at", { ascending: false }),
          db.from("translation_proxy_assignments").select("id,device_id,pool_type,account_key,proxy_id,fixed,status,last_success_at,last_failure_at,last_error,updated_at").order("updated_at", { ascending: false }),
          db.from("translation_direct_egress").select("*").order("updated_at", { ascending: false }),
          db.from("translation_proxy_settings").select("*").eq("singleton", true).single(),
          db.from("translation_proxy_activity_logs").select("*").order("created_at", { ascending: false }).limit(100),
        ]);
        return reply({ ok: true, pool: pool.data || [], devices: devices.data || [], assignments: assignments.data || [], egress: egress.data || [], settings: settings.data, logs: logs.data || [] });
      }
      if (action === "admin_import") {
        const rows = (Array.isArray(body.proxies) ? body.proxies : []).slice(0, 2000).map((p: any) => ({ label: String(p.label || `${p.host}:${p.port}`).slice(0, 120), protocol: String(p.protocol || "socks5").toLowerCase(), host: String(p.host || "").trim(), port: Number(p.port), username: String(p.username || ""), password: String(p.password || ""), region: String(p.region || "").slice(0, 60), pool_type: validPool(p.poolType || body.poolType), max_accounts: Math.max(1, Math.min(500, Number(p.maxAccounts || body.maxAccounts || 3))), notes: String(p.notes || "").slice(0, 500), enabled: true, health_status: "unknown", updated_at: now() })).filter((p: any) => ["http","https","socks4","socks5"].includes(p.protocol) && p.host && Number.isInteger(p.port) && p.port > 0 && p.port < 65536);
        const { error } = await db.from("translation_proxy_pool").upsert(rows, { onConflict: "protocol,host,port,username" });
        if (error) throw error;
        EdgeRuntime.waitUntil(healthSweep());
        return reply({ ok: true, imported: rows.length, checking: true });
      }
      if (action === "admin_bulk_limit") {
        const maxAccounts = Math.max(1, Math.min(500, Number(body.maxAccounts || 3)));
        const { error } = await db.from("translation_proxy_pool").update({ max_accounts: maxAccounts, updated_at: now() }).eq("pool_type", "translation_pool");
        if (error) throw error;
        return reply({ ok: true, maxAccounts });
      }
      if (action === "admin_update_proxy") {
        const values = { label: String(body.label || "").slice(0, 120), pool_type: validPool(body.poolType), max_accounts: Math.max(1, Math.min(500, Number(body.maxAccounts || 3))), region: String(body.region || "").slice(0, 60), notes: String(body.notes || "").slice(0, 500), updated_at: now() };
        const { error } = await db.from("translation_proxy_pool").update(values).eq("id", String(body.proxyId || ""));
        if (error) throw error;
        return reply({ ok: true });
      }
      if (action === "admin_toggle_proxy") {
        const enabled = body.enabled === true;
        const { error } = await db.from("translation_proxy_pool").update({ enabled, health_status: enabled ? "unknown" : "disabled", updated_at: now() }).eq("id", String(body.proxyId || ""));
        if (error) throw error;
        return reply({ ok: true });
      }
      if (action === "admin_retest_proxy") {
        const proxyId = String(body.proxyId || "");
        const { data: proxy, error } = await db.from("translation_proxy_pool").select("*").eq("id", proxyId).single();
        if (error) throw error;
        await db.from("translation_proxy_pool").update({ enabled: true, health_status: "unknown", cooldown_until: null, last_error: null, updated_at: now() }).eq("id", proxyId);
        const result = await checkAndSaveProxy({ ...proxy, enabled: true });
        return reply({ ok: true, available: result.ok, latencyMs: result.latencyMs, message: result.ok ? "线路可用" : "线路不可用", error: result.error });
      }
      if (action === "admin_delete_proxy") {
        const proxyId = String(body.proxyId || "");
        await db.from("translation_proxy_assignments").update({ proxy_id: null, fixed: false, updated_at: now() }).eq("proxy_id", proxyId);
        const { error } = await db.from("translation_proxy_pool").delete().eq("id", proxyId);
        if (error) throw error;
        return reply({ ok: true });
      }
      if (action === "admin_device_status") {
        const { error } = await db.from("translation_proxy_devices").update({ status: String(body.status || "paused"), updated_at: now() }).eq("id", String(body.deviceId || ""));
        if (error) throw error;
        return reply({ ok: true });
      }
      if (action === "admin_auto_assign") {
        const next = await autoAssignDevice(String(body.deviceId || ""));
        return reply({ ok: true, proxy: publicProxy(next) });
      }
      if (action === "admin_bind") {
        const proxy = await bindDeviceToProxy(String(body.deviceId || ""), String(body.proxyId || ""), body.fixed === true);
        return reply({ ok: true, proxy: publicProxy(proxy) });
      }
      if (action === "admin_unbind") {
        const { error } = await db.from("translation_proxy_assignments").delete().eq("id", String(body.assignmentId || ""));
        if (error) throw error;
        return reply({ ok: true });
      }
      if (action === "admin_update_settings") {
        const values = { allow_direct_translation: body.allowDirectTranslation !== false, prefer_direct_translation: body.preferDirectTranslation !== false, failure_threshold: Math.max(1, Math.min(10, Number(body.failureThreshold || 2))), request_timeout_ms: Math.max(500, Math.min(10000, Number(body.requestTimeoutMs || 2500))), cooldown_seconds: Math.max(5, Math.min(3600, Number(body.cooldownSeconds || 60))), routing_mode: ["smart","direct_first","proxy_first"].includes(String(body.routingMode)) ? String(body.routingMode) : "smart", max_direct_devices_per_egress: Math.max(1, Math.min(100, Number(body.maxDirectDevicesPerEgress || 2))), updated_at: now() };
        const healthCheckIntervalMinutes = [1,2,5,10,15,30,60].includes(Number(body.healthCheckIntervalMinutes)) ? Number(body.healthCheckIntervalMinutes) : null;
        const { error } = await db.from("translation_proxy_settings").update(values).eq("singleton", true);
        if (error) throw error;
        if (healthCheckIntervalMinutes) {
          const { error: scheduleError } = await db.rpc("set_translation_health_interval", { p_minutes: healthCheckIntervalMinutes });
          if (scheduleError) throw scheduleError;
        }
        return reply({ ok: true, settings: { ...values, ...(healthCheckIntervalMinutes ? { health_check_interval_minutes: healthCheckIntervalMinutes } : {}) } });
      }
      return reply({ ok: false, message: "未知管理操作" }, 400);
    }

    const device = await deviceFor(req);
    if (!device) return reply({ ok: false, message: "设备未登记或已停用" }, 401);
    const poolType = validPool(body.poolType), accountKey = String(body.accountKey || "default").slice(0, 180);
    if (action === "assignment") {
      const { data: settings } = await db.from("translation_proxy_settings").select("*").eq("singleton", true).single();
      const result = await assign(device, poolType, accountKey, Array.isArray(body.excludedProxyIds) ? body.excludedProxyIds.map(String) : [], body.forceSwitch === true);
      let directEligible = settings?.allow_direct_translation !== false && poolType !== "tn_groups";
      if (directEligible && settings?.routing_mode === "smart" && device.last_ip) {
        const { data: learned } = await db.from("translation_direct_egress").select("*").eq("public_ip", device.last_ip).maybeSingle();
        if (!learned) await db.from("translation_direct_egress").insert({ public_ip: device.last_ip, learned_capacity: Math.min(2, Number(settings?.max_direct_devices_per_egress || 2)) });
        const { data: peers } = await db.from("translation_proxy_devices").select("id").eq("status", "active").eq("last_ip", device.last_ip).order("created_at").limit(1000);
        const capacity = Math.min(Number(learned?.learned_capacity || 2), Number(settings?.max_direct_devices_per_egress || 100));
        directEligible = (!learned?.cooldown_until || new Date(learned.cooldown_until).getTime() <= Date.now()) && (peers || []).findIndex(row => row.id === device.id) < capacity;
      }
      const preferDirect = settings?.routing_mode === "direct_first" || (settings?.routing_mode === "smart" && directEligible);
      return reply({ ok: true, proxy: publicProxy(result.proxy), directAllowed: directEligible, directEligible, preferDirect, routeOrder: preferDirect ? ["direct", "proxy"] : ["proxy", "direct"], requestTimeoutMs: Number(settings?.request_timeout_ms || 2500), message: result.proxy || directEligible ? "" : "没有可用线路" });
    }
    if (action === "report_success") {
      const proxyId = String(body.proxyId || "");
      if (body.routeType === "direct" && device.last_ip) {
        const { data: state } = await db.from("translation_direct_egress").select("*").eq("public_ip", device.last_ip).maybeSingle();
        const streak = Number(state?.success_streak || 0) + 1, capacity = Math.min(100, Number(state?.learned_capacity || 2) + (streak >= 10 ? 1 : 0));
        await db.from("translation_direct_egress").upsert({ public_ip: device.last_ip, learned_capacity: capacity, success_streak: streak >= 10 ? 0 : streak, failure_count: 0, cooldown_until: null, last_success_at: now(), updated_at: now() });
        return reply({ ok: true, learnedCapacity: capacity });
      }
      await db.from("translation_proxy_pool").update({ health_status: "healthy", failure_count: 0, latency_ms: Math.max(0, Math.min(120000, Number(body.latencyMs || 0))) || null, last_error: null, last_checked_at: now(), last_used_at: now(), cooldown_until: null }).eq("id", proxyId);
      await db.from("translation_proxy_assignments").update({ last_success_at: now(), last_error: null, updated_at: now() }).eq("device_id", device.id).eq("pool_type", poolType).eq("account_key", accountKey);
      return reply({ ok: true });
    }
    if (action === "report_failure") {
      const proxyId = String(body.proxyId || ""), statusCode = Number(body.statusCode || 0), localOnly = statusCode === 403 || statusCode === 429;
      const { data: settings } = await db.from("translation_proxy_settings").select("failure_threshold,cooldown_seconds").eq("singleton", true).single();
      if (body.routeType === "direct" && device.last_ip) {
        const { data: state } = await db.from("translation_direct_egress").select("*").eq("public_ip", device.last_ip).maybeSingle();
        const failures = Number(state?.failure_count || 0) + 1, capacity = Math.max(1, Number(state?.learned_capacity || 2) - 1), seconds = statusCode === 403 || statusCode === 429 ? 300 : Math.max(30, Number(settings?.cooldown_seconds || 60));
        await db.from("translation_direct_egress").upsert({ public_ip: device.last_ip, learned_capacity: capacity, success_streak: 0, failure_count: failures, cooldown_until: new Date(Date.now() + seconds * 1000).toISOString(), last_failure_at: now(), updated_at: now() });
      }
      if (proxyId && !localOnly) {
        const { data: current } = await db.from("translation_proxy_pool").select("failure_count").eq("id", proxyId).maybeSingle();
        const failures = Number(current?.failure_count || 0) + 1, cooling = failures >= Number(settings?.failure_threshold || 2);
        await db.from("translation_proxy_pool").update({ failure_count: failures, health_status: cooling ? "cooldown" : "unknown", cooldown_until: cooling ? new Date(Date.now() + Number(settings?.cooldown_seconds || 60) * 1000).toISOString() : null, last_error: String(body.reason || "线路失败").slice(0, 500), last_checked_at: now() }).eq("id", proxyId);
      }
      await db.from("translation_proxy_assignments").update({ last_failure_at: now(), last_error: String(body.reason || "线路失败").slice(0, 500), updated_at: now() }).eq("device_id", device.id).eq("pool_type", poolType).eq("account_key", accountKey);
      const result = await assign(device, poolType, accountKey, [proxyId, ...(Array.isArray(body.excludedProxyIds) ? body.excludedProxyIds.map(String) : [])], true);
      return reply({ ok: true, proxy: publicProxy(result.proxy), directAllowed: poolType !== "tn_groups" });
    }
    return reply({ ok: false, message: "未知操作" }, 400);
  } catch (error) {
    console.error("haituo-translation-control", error);
    return reply({ ok: false, message: "服务器处理失败：" + String((error as any)?.message || error || "未知错误").slice(0, 300), errorCode: String((error as any)?.code || "EDGE_FAILURE") }, 500);
  }
});

