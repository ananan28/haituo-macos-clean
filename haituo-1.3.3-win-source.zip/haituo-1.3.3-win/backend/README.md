# 翻译池后台实际源码导出

来源：Supabase 项目 vdgrirosqwzlibvxsdnp，读取时间 2026-10-14 UTC。仅执行读取，没有更改线上项目。

- functions/haituo-translation-control/index.ts：线上版本 14 的真实函数源码。
- functions/haituo-translation-gateway/index.ts：线上版本 2 的真实函数源码。
- schema-catalog.json：public 下 7 张表的 94 个列定义、约束、索引、RLS 状态、授权、触发器及 5 个数据库函数定义。只含结构，不包含表内记录或 Vault 密钥。

这不是已验证的一键后台部署工程。schema-catalog.json 是结构快照，不是可直接执行的迁移 SQL。部署迁移、Vault/pg_cron 扩展、定时任务配置及管理前端仍需补齐和验证。

函数运行依赖 SUPABASE_URL 和 SUPABASE_SERVICE_ROLE_KEY，后者只能配置在服务端。源码还保留线上安装/管理员/健康检查凭据的哈希；原始管理密码无法从哈希还原。迁移时必须自行设置新凭据并同步配置客户端及管理端。不要把 service-role 或个人密钥写入客户端。

当前客户端的 username-login 位于另一个项目 ffnvtyadqizvrikjjssy。现有连接账号未列出该项目，未取回该登录函数及其数据库，不能用其他项目同名或类似代码替代。

当前工程没有新增、删除或改造登录系统。本导出也不包含用户账号、聊天记录、代理密码、个人 API 密钥及设备令牌。
